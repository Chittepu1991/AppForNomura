﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using BinarySearchTreeNP;

namespace GitRepoCommentsApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Task.WaitAll(ExecuteAsync());
            Console.ReadLine();
        }

        public static async Task ExecuteAsync()
        {
            var data = new JArray();
            System.Net.Http.HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/vnd.github.v3+json"));
            client.DefaultRequestHeaders.Add("User-Agent", "GitRepoCommentsApp");
            client.DefaultRequestHeaders.Add("Authorization", "Token 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");
            var stringTask = client.GetStringAsync("https://api.github.com/repos/Chittepu1991/appfornomura/commits");
            // var stringTask = client.GetStringAsync("https://api.github.com/repos/Chittepu1991/gitcommits/commits");

            var jsonString = await stringTask;
            List<string> olistString;
            olistString = GetMessagesFromCommits(jsonString);
            BinarySortbasedOnASCIICode(olistString);
            Console.WriteLine("\n" + "*************Git Commit Comment list*************");
            foreach (var item in olistString)
            {
                Console.WriteLine(item + "\n");
            }

        }


        public static void BinarySortbasedOnASCIICode(List<string> ostring)
        {
            String[] arr = ostring.ToArray();
            int n = arr.Length;

            foreach (var itemList in ostring)
            {
                BinarySearchTree tree = new BinarySearchTree();
                var splitrow = itemList.Split();
                foreach (var splitItem in splitrow)
                {
                    byte[] asciiBytes = Encoding.ASCII.GetBytes(splitItem);
                    int makeitsum = 0;
                    foreach (var item in asciiBytes)
                    {
                        makeitsum = makeitsum + item;
                    }
                    tree.insert(makeitsum);
                }
                tree.inorder();
                Console.WriteLine("-----Commited Comments Ascii codes sorted in asc order-----\n");
                Console.WriteLine(tree);
            }
        }

        static int getValue(String s)
        {
            int sum = 0;

            for (int i = 0; i < s.Length; i++)
            {
                sum += s[i];
            }
            return sum;
        }



        public static List<string> GetMessagesFromCommits(string json)
        {
            DataTable oData = new DataTable();
            var trgArray = new JArray();
            List<string> otrgArray = new List<string>();
            JArray jsonArray = JArray.Parse(json);
            foreach (JObject row in jsonArray.Children<JObject>())
            {
                var query = row.Descendants()
                                .OfType<JProperty>()
                                .Where(p => p.Value.Type != JTokenType.Array && p.Value.Type != JTokenType.Object);
                var cleanRow = new JObject();
                var jArray = new JArray();
                foreach (JProperty column in query)
                {
                    string stringvalue = "";
                    if (column.Value is JValue)
                    {
                        if (column.Name == "message")
                        {
                            stringvalue = (string)column.Value;
                            otrgArray.Add(stringvalue);
                        }
                    }
                }
            }
            Console.WriteLine(otrgArray);
            return otrgArray;
        }
    }
}

